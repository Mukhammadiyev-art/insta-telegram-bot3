from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, ContextTypes
import instaloader
from config import BOT_TOKEN

loader = instaloader.Instaloader()

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Instagram link yuboring.")

async def download(update: Update, context: ContextTypes.DEFAULT_TYPE):
    url = update.message.text.strip()
    try:
        shortcode = url.split("/")[-2]
        post = instaloader.Post.from_shortcode(loader.context, shortcode)
        loader.download_post(post, target="download")
        await update.message.reply_text("Yuklab olindi.")
    except Exception as e:
        await update.message.reply_text(f"Xatolik: {e}")

app = ApplicationBuilder().token(BOT_TOKEN).build()
app.add_handler(CommandHandler("start", start))
app.add_handler(CommandHandler("download", download))

app.run_polling()
