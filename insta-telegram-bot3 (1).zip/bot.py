import logging
import os
from aiogram import Bot, Dispatcher, types
from aiogram.types import FSInputFile
from aiogram.utils import executor
import instaloader

TOKEN = os.getenv("BOT_TOKEN", "YOUR_BOT_TOKEN_HERE")
bot = Bot(token=TOKEN)
dp = Dispatcher(bot)

@dp.message_handler(commands=['start'])
async def send_welcome(message: types.Message):
    await message.reply("Instagram yuklovchi botga xush kelibsiz! Link yuboring.")

@dp.message_handler()
async def handle_instagram_link(message: types.Message):
    url = message.text.strip()
    if "instagram.com" not in url:
        await message.reply("Iltimos, to‘g‘ri Instagram havolasini yuboring.")
        return

    try:
        loader = instaloader.Instaloader()
        shortcode = url.split("/")[-2]
        post = instaloader.Post.from_shortcode(loader.context, shortcode)
        filename = f"{shortcode}.jpg"
        loader.download_pic(filename, post.url, post.date_utc)
        photo = FSInputFile(filename)
        await message.reply_photo(photo)
        os.remove(filename)
    except Exception as e:
        await message.reply(f"Yuklab bo‘lmadi: {e}")

if __name__ == '__main__':
    logging.basicConfig(level=logging.INFO)
    executor.start_polling(dp, skip_updates=True)